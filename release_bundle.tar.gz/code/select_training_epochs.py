#!/usr/bin/env python3
"""Select the full-data duration from five LUT-disjoint validation folds."""

from __future__ import annotations

import argparse
import hashlib
import json
import statistics
from pathlib import Path


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--evaluation", type=Path, action="append", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if len(args.evaluation) != 5:
        raise RuntimeError("exactly five validation-fold evaluations are required")
    if args.output.exists():
        raise RuntimeError(f"refusing to overwrite epoch-selection result: {args.output}")
    config = json.loads(args.config.read_text(encoding="utf-8"))
    expected_config_sha256 = sha256_file(args.config)
    rows = []
    for path in args.evaluation:
        payload = json.loads(path.read_text(encoding="utf-8"))
        if (
            payload.get("schema") != "reference-selector-validation-fold.v1"
            or payload.get("status") != "completed"
            or payload.get("protocol", {}).get("official_test_accessed") is not False
            or payload.get("input_hashes", {}).get("config") != expected_config_sha256
        ):
            raise RuntimeError(f"invalid validation-fold result: {path}")
        rows.append({
            "validation_fold": int(payload["validation_fold"]),
            "best_epoch": int(payload["best_epoch"]),
            "best_validation_metrics": payload["best_validation_metrics"],
            "evaluation_sha256": sha256_file(path),
            "checkpoint_sha256": payload["checkpoint_sha256"],
        })
    rows.sort(key=lambda row: row["validation_fold"])
    if [row["validation_fold"] for row in rows] != list(range(5)):
        raise RuntimeError("validation results must cover folds 0..4")
    best_epochs = [row["best_epoch"] for row in rows]
    selected_epoch = int(statistics.median(best_epochs))
    if selected_epoch != int(config["training"]["full_training_epochs"]):
        raise RuntimeError("fold median does not match full_training_epochs")
    result = {
        "schema": "reference-selector-epoch-selection.v1",
        "status": "completed",
        "rule": "median of five LUT-disjoint validation best epochs",
        "selected_full_training_epoch": selected_epoch,
        "validation_best_epochs": best_epochs,
        "folds": rows,
        "config_sha256": expected_config_sha256,
        "official_test_accessed": False,
        "official_test_used_for_epoch_selection": False,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
