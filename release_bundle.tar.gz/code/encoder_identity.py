"""Verify the exact frozen encoder and preprocessing files used by the selector."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Dict


DEFAULT_IDENTITY_PATH = (
    Path(__file__).resolve().parents[1] / "metadata" / "encoder_identities.json"
)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def expected_encoder_files(
    encoder: str,
    identity_path: Path = DEFAULT_IDENTITY_PATH,
) -> Dict[str, str]:
    identity = json.loads(identity_path.read_text(encoding="utf-8"))
    if identity.get("schema") != "reference-frame-selector-encoder-identities.v1":
        raise RuntimeError(f"invalid encoder identity file: {identity_path}")
    expected = identity.get(encoder, {}).get("files", {})
    if not expected:
        raise RuntimeError(f"missing {encoder} identity in {identity_path}")
    return {str(name): str(value) for name, value in expected.items()}


def verify_encoder_root(
    encoder: str,
    root: Path,
    identity_path: Path = DEFAULT_IDENTITY_PATH,
) -> Dict[str, str]:
    expected = expected_encoder_files(encoder, identity_path)
    actual: Dict[str, str] = {}
    for name, expected_sha256 in expected.items():
        path = root / name
        if not path.is_file():
            raise RuntimeError(f"missing {encoder} file: {path}")
        actual[name] = sha256_file(path)
        if actual[name] != expected_sha256:
            raise RuntimeError(
                f"{encoder} identity mismatch for {path}: "
                f"expected {expected_sha256}, got {actual[name]}"
            )
    return actual


def verify_dinov2_root(root: Path) -> Dict[str, str]:
    return verify_encoder_root("dinov2", root)


def verify_clip_root(root: Path) -> Dict[str, str]:
    return verify_encoder_root("clip", root)
