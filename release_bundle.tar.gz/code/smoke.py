#!/usr/bin/env python3
"""Deterministic architecture and checkpoint checks for the final selector."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import torch

from model import ReferenceFrameUtilityModel


def main() -> int:
    package_root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--config", type=Path, default=package_root / "config" / "selector_config.json"
    )
    parser.add_argument(
        "--checkpoint", type=Path, default=package_root / "weights" / "selector_checkpoint.pt"
    )
    args = parser.parse_args()
    config = json.loads(args.config.read_text(encoding="utf-8"))
    if config.get("status") != "final_method_configuration":
        raise RuntimeError("configuration is not the final method configuration")
    torch.manual_seed(20260821)
    model = ReferenceFrameUtilityModel(config).eval()
    checkpoint = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
    if checkpoint.get("config") != config or int(checkpoint.get("epoch", -1)) != 7:
        raise RuntimeError("checkpoint metadata does not match the final configuration")
    model.load_state_dict(checkpoint["model_state"], strict=True)
    parameter_count = sum(parameter.numel() for parameter in model.parameters())
    if parameter_count != 3_531_233:
        raise RuntimeError(f"unexpected parameter count: {parameter_count}")

    candidate_semantic = torch.randn(1, 20, 64, 384)
    candidate_pixels = torch.randint(0, 256, (1, 20, 32, 32, 3), dtype=torch.uint8)
    reference_semantic = torch.randn(1, 64, 384)
    reference_pixels = torch.randint(0, 256, (1, 32, 32, 3), dtype=torch.uint8)
    candidate_clip = torch.randn(1, 20, 512)
    reference_clip = torch.randn(1, 512)
    scores = model(
        candidate_semantic,
        candidate_pixels,
        reference_semantic,
        reference_pixels,
        candidate_clip,
        reference_clip,
    )
    if scores.shape != (1, 20) or not torch.isfinite(scores).all():
        raise RuntimeError("score shape or finiteness check failed")

    order = torch.tensor([7, 1, 18, 0, 14, 5, 8, 11, 2, 16, 6, 19, 3, 10, 12, 4, 15, 9, 17, 13])
    permuted = model(
        candidate_semantic[:, order],
        candidate_pixels[:, order],
        reference_semantic,
        reference_pixels,
        candidate_clip[:, order],
        reference_clip,
    )
    if not torch.allclose(permuted, scores[:, order], atol=2e-5, rtol=2e-5):
        raise RuntimeError("candidate permutation equivariance failed")

    model.train()
    float_pixels = candidate_pixels.float().div(255.0).requires_grad_(True)
    train_scores = model(
        candidate_semantic,
        float_pixels,
        reference_semantic,
        reference_pixels,
        candidate_clip,
        reference_clip,
    )
    train_scores.square().mean().backward()
    color_gradient = sum(
        float(parameter.grad.abs().sum())
        for parameter in model.color_encoder.parameters()
        if parameter.grad is not None
    )
    if color_gradient <= 0.0 or float_pixels.grad is None:
        raise RuntimeError("color encoder gradient check failed")

    try:
        model(
            candidate_semantic,
            candidate_pixels[:, :, :16],
            reference_semantic,
            reference_pixels,
            candidate_clip,
            reference_clip,
        )
    except ValueError:
        pass
    else:
        raise RuntimeError("invalid pixel shape was not rejected")

    print(
        "final selector checks passed "
        f"({parameter_count} parameters, 20-candidate permutation equivariance)"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
