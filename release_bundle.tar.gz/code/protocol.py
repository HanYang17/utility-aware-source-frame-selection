"""Training protocol checks for the complete VCG training split."""

from __future__ import annotations

from typing import Any, Dict

import numpy as np


EXPECTED_TRAIN_LUT_IDS = set(range(1, 47)) | set(range(50, 91))


def validate_training_contract(
    plan: Dict[str, Any],
    quality: np.ndarray,
    clip_position: np.ndarray,
    case_fold: np.ndarray,
) -> Dict[str, Any]:
    """Prove that labels cover the full VCG train split with LUT-isolated folds."""
    if quality.shape != (2900, 20) or not np.isfinite(quality).all():
        raise RuntimeError("quality labels must be finite with shape 2900x20")
    if clip_position.shape != (2900,) or not np.issubdtype(
        clip_position.dtype, np.integer
    ):
        raise RuntimeError("VCG baseline positions must be an integer vector of length 2,900")
    if np.any(clip_position < 0) or np.any(clip_position >= 20):
        raise RuntimeError("VCG baseline positions must be in 0..19")
    if case_fold.shape != (2900,) or not np.issubdtype(case_fold.dtype, np.integer):
        raise RuntimeError("case folds must be an integer vector of length 2,900")
    if set(np.unique(case_fold).astype(int).tolist()) != set(range(5)):
        raise RuntimeError("case folds must cover exactly folds 0..4")

    cases = plan.get("cases", [])
    if (
        int(plan.get("case_count", -1)) != 2900
        or int(plan.get("candidate_count_per_case", -1)) != 20
        or len(cases) != 2900
        or plan.get("final_test_gt_accessed") is not False
    ):
        raise RuntimeError("plan is not the required 2,900-case training plan")
    by_id = {int(row.get("case_id", -1)): row for row in cases}
    if set(by_id) != set(range(2900)):
        raise RuntimeError("training plan must cover unique case IDs 0..2899")

    lut_by_case = np.asarray(
        [int(by_id[case_id]["target_lut_id"]) for case_id in range(2900)],
        dtype=np.int64,
    )
    observed_lut_ids = set(np.unique(lut_by_case).tolist())
    if observed_lut_ids != EXPECTED_TRAIN_LUT_IDS:
        raise RuntimeError(
            "training plan must use the 87 LUT IDs present in the complete "
            "2,900-case plan (1..46 and 50..90)"
        )

    fold_luts = []
    lut_to_fold: Dict[int, int] = {}
    for fold in range(5):
        mask = case_fold == fold
        values = sorted(set(lut_by_case[mask].astype(int).tolist()))
        if not values:
            raise RuntimeError(f"fold {fold} has no target LUTs")
        fold_luts.append(values)
        for lut_id in values:
            previous = lut_to_fold.setdefault(lut_id, fold)
            if previous != fold:
                raise RuntimeError(
                    f"target LUT {lut_id} leaks across folds {previous} and {fold}"
                )
    if set(lut_to_fold) != EXPECTED_TRAIN_LUT_IDS:
        raise RuntimeError("LUT-isolated folds do not cover all 87 train LUT IDs")

    return {
        "case_count": 2900,
        "candidate_count": 20,
        "fold_case_counts": [int(np.sum(case_fold == fold)) for fold in range(5)],
        "fold_lut_counts": [len(values) for values in fold_luts],
        "fold_lut_ids": fold_luts,
        "cross_fold_lut_overlap_count": 0,
        "train_lut_ids": "1-46,50-90",
        "train_lut_id_count": 87,
        "absent_ids_within_1_to_90": [47, 48, 49],
        "official_test_gt_accessed": False,
    }
