#!/usr/bin/env python3
"""Extract normalized DINOv2 patch descriptors for the 100 evaluation cases."""

from __future__ import annotations

import argparse
import json
import os
import time
import traceback
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from transformers import AutoImageProcessor, Dinov2Model

from encoder_identity import verify_dinov2_root
from extract_aligned_rgb_cache_test import (
    CANDIDATE_INDICES,
    atomic_json,
    atomic_npz,
    read_selected_frames,
    validate_index,
)


def pool_16_to_8(tokens: torch.Tensor) -> torch.Tensor:
    batch, count, dimension = tokens.shape
    if count != 256:
        raise RuntimeError(f"DINOv2 patch count is not 16x16: {count}")
    grid = tokens.reshape(batch, 16, 16, dimension).permute(0, 3, 1, 2)
    return (
        F.avg_pool2d(grid, kernel_size=2, stride=2)
        .permute(0, 2, 3, 1)
        .reshape(batch, 64, dimension)
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--index", type=Path, required=True)
    parser.add_argument("--expected-index-sha256", required=True)
    parser.add_argument("--model-root", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    args = parser.parse_args()
    if not torch.cuda.is_available() or torch.cuda.device_count() != 1:
        raise RuntimeError("exactly one CUDA-visible GPU is required")
    manifest_path = args.output_root / "shard_0" / "manifest.json"
    if manifest_path.exists():
        raise RuntimeError(f"refusing to overwrite semantic test cache: {manifest_path}")
    rows = validate_index(args.index, args.expected_index_sha256)
    encoder_files = verify_dinov2_root(args.model_root)
    identity = {
        "schema": "reference-selector-semantic-test-cache.v1",
        "status": "running",
        "case_ids": list(range(100)),
        "case_count": 100,
        "candidate_count_per_case": 20,
        "candidate_indices": CANDIDATE_INDICES,
        "patch_count": 64,
        "embedding_dimension": 384,
        "shard_id": 0,
        "shard_count": 1,
        "index_sha256": args.expected_index_sha256,
        "encoder_files": encoder_files,
        "official_test_accessed": True,
        "test_gt_accessed": False,
        "test_gt_as_model_input": False,
        "target_lut_accessed": False,
        "candidate_psnr_accessed": False,
    }
    atomic_json(manifest_path, {**identity, "completed_case_count": 0})

    os.environ["HF_HUB_OFFLINE"] = "1"
    os.environ["TRANSFORMERS_OFFLINE"] = "1"
    processor = AutoImageProcessor.from_pretrained(
        str(args.model_root), local_files_only=True
    )
    model = Dinov2Model.from_pretrained(
        str(args.model_root), local_files_only=True
    ).requires_grad_(False).cuda().eval()
    started = time.time()
    try:
        for completed, row in enumerate(rows, start=1):
            case_id = int(row["global_index"])
            frames = read_selected_frames(Path(row["video"]), CANDIDATE_INDICES)
            candidates = [frames[index] for index in CANDIDATE_INDICES]
            reference = np.asarray(
                Image.open(Path(row["case_root"]) / row["reference_frame"]).convert("RGB")
            )
            pixel_values = processor(
                images=candidates + [reference], return_tensors="pt"
            ).pixel_values.cuda()
            with torch.no_grad(), torch.cuda.amp.autocast(enabled=True):
                output = model(pixel_values=pixel_values, return_dict=True)
            semantic = F.normalize(output.last_hidden_state[:, 1:].float(), dim=-1)
            semantic = pool_16_to_8(semantic).cpu().numpy().astype(np.float16)
            atomic_npz(
                args.output_root / "shard_0" / "cases" / f"case_{case_id:04d}.npz",
                semantic=semantic,
            )
            atomic_json(
                manifest_path,
                {
                    **identity,
                    "completed_case_count": completed,
                    "last_completed_case_id": case_id,
                    "elapsed_seconds": time.time() - started,
                },
            )
        atomic_json(
            manifest_path,
            {
                **identity,
                "status": "completed",
                "completed_case_count": 100,
                "elapsed_seconds": time.time() - started,
            },
        )
    except Exception as error:
        atomic_json(
            manifest_path,
            {
                **identity,
                "status": "failed",
                "completed_case_count": completed - 1 if "completed" in locals() else 0,
                "error": repr(error),
                "traceback": traceback.format_exc(),
            },
        )
        raise
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
