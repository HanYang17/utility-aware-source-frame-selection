"""Training-cache loader for semantic, RGB, and frozen CLIP features."""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List

import numpy as np
import torch
from torch.utils.data import Dataset

from cache_contract import (
    validate_aligned_rgb_cache,
    validate_clip_cache,
    validate_semantic_cache,
)


class AlignedPixelDataset(Dataset):
    def __init__(
        self,
        semantic_root: Path,
        semantic_shards: int,
        pixel_root: Path,
        pixel_shards: int,
        clip_root: Path,
        clip_shards: int,
        case_ids: List[int],
        quality: np.ndarray,
        clip_position: np.ndarray,
        permute: bool,
    ) -> None:
        self.semantic_root = semantic_root
        self.semantic_shards = semantic_shards
        self.pixel_root = pixel_root
        self.pixel_shards = pixel_shards
        self.clip_root = clip_root
        self.clip_shards = clip_shards
        self.case_ids = case_ids
        self.quality = quality
        self.clip_position = clip_position
        self.permute = permute

    def __len__(self) -> int:
        return len(self.case_ids)

    def __getitem__(self, index: int) -> Dict[str, torch.Tensor]:
        case_id = self.case_ids[index]
        semantic_path = (
            self.semantic_root
            / f"shard_{case_id % self.semantic_shards}"
            / "cases"
            / f"case_{case_id:04d}.npz"
        )
        pixel_path = (
            self.pixel_root
            / f"shard_{case_id % self.pixel_shards}"
            / "cases"
            / f"case_{case_id:04d}.npz"
        )
        clip_path = (
            self.clip_root
            / f"shard_{case_id % self.clip_shards}"
            / "cases"
            / f"case_{case_id:04d}.npz"
        )
        with np.load(semantic_path, allow_pickle=False) as payload:
            semantic = payload["semantic"].astype(np.float32)
        with np.load(pixel_path, allow_pickle=False) as payload:
            pixels = payload["pixels"]
        with np.load(clip_path, allow_pickle=False) as payload:
            clip = payload["clip_embedding"].astype(np.float32)
        if semantic.shape != (21, 64, 384):
            raise RuntimeError(f"semantic cache shape mismatch: {case_id}")
        if pixels.shape != (21, 32, 32, 3) or pixels.dtype != np.uint8:
            raise RuntimeError(f"aligned RGB cache shape/dtype mismatch: {case_id}")
        if clip.shape != (21, 512) or not np.isfinite(clip).all():
            raise RuntimeError(f"CLIP cache shape/finite mismatch: {case_id}")
        order = torch.randperm(20) if self.permute else torch.arange(20)
        numpy_order = order.numpy()
        local_clip_position = int(
            np.flatnonzero(numpy_order == self.clip_position[case_id])[0]
        )
        return {
            "case_id": torch.tensor(case_id, dtype=torch.long),
            "candidate_semantic": torch.from_numpy(semantic[:20][numpy_order]),
            "candidate_pixels": torch.from_numpy(pixels[:20][numpy_order]),
            "reference_semantic": torch.from_numpy(semantic[20]),
            "reference_pixels": torch.from_numpy(pixels[20]),
            "candidate_clip": torch.from_numpy(clip[:20][numpy_order]),
            "reference_clip": torch.from_numpy(clip[20]),
            "quality": torch.from_numpy(self.quality[case_id][numpy_order]),
            "clip_position": torch.tensor(local_clip_position, dtype=torch.long),
            "original_position": order,
        }
