#!/usr/bin/env python3
"""Extract frozen CLIP image-context embeddings from the aligned RGB cache.

The cache contains 20 candidate RGB images and the provided training reference
image. CLIP is used only as a frozen pooled-context encoder; no
quality label, target LUT, or official-test file is read here.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import time
import traceback
from pathlib import Path
from typing import Any, Dict

import numpy as np
import torch
from PIL import Image
from transformers import CLIPModel, CLIPProcessor

from encoder_identity import verify_clip_root


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def atomic_json(path: Path, payload: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    partial = path.with_suffix(path.suffix + ".partial")
    partial.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(partial, path)


def atomic_npz(path: Path, **arrays: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    partial = path.with_suffix(path.suffix + ".partial")
    with partial.open("wb") as handle:
        np.savez_compressed(handle, **arrays)
    os.replace(partial, path)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--rgb-root", type=Path, required=True)
    parser.add_argument("--clip-model-root", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--shard-id", type=int, required=True)
    parser.add_argument("--shard-count", type=int, required=True)
    parser.add_argument("--device", choices=("cpu", "cuda"), default="cuda")
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    if args.shard_count < 1 or not 0 <= args.shard_id < args.shard_count:
        raise ValueError("invalid shard")
    config = json.loads(args.config.read_text(encoding="utf-8"))
    plan = json.loads(args.plan.read_text(encoding="utf-8"))
    data = config["data"]
    total = int(data["train_case_count"])
    if (
        sha256_file(args.plan) != data["plan_sha256"]
        or plan.get("case_count") != total
        or plan.get("candidate_count_per_case") != 20
        or data.get("official_test_accessed") is not False
        or data.get("test_ground_truth_as_model_input") is not False
        or data.get("candidate_psnr_as_model_input") is not False
    ):
        raise RuntimeError("invalid or test-contaminated training contract")
    case_ids = [case_id for case_id in range(total) if case_id % args.shard_count == args.shard_id]
    identity = {
        "schema": "reference-selector-clip-cache.v1",
        "status": "running",
        "case_ids": case_ids,
        "case_count": len(case_ids),
        "candidate_count_per_case": 20,
        "embedding_dimension": 512,
        "shard_id": args.shard_id,
        "shard_count": args.shard_count,
        "plan_sha256": sha256_file(args.plan),
        "config_sha256": sha256_file(args.config),
        "clip_model_root": str(args.clip_model_root),
        "official_test_accessed": False,
        "test_gt_accessed": False,
        "candidate_psnr_accessed": False,
    }
    manifest_path = args.output_root / "manifest.json"
    if manifest_path.exists():
        if not args.resume:
            raise RuntimeError(f"refusing to overwrite existing cache: {manifest_path}")
        existing = json.loads(manifest_path.read_text(encoding="utf-8"))
        for key, value in identity.items():
            if key != "status" and existing.get(key) != value:
                raise RuntimeError(f"incompatible resumable cache identity: {key}")
    completed_ids = set()
    for case_id in case_ids:
        case_path = args.output_root / "cases" / f"case_{case_id:04d}.npz"
        if not case_path.exists():
            continue
        with np.load(case_path, allow_pickle=False) as payload:
            embedding = payload["clip_embedding"]
        if embedding.shape != (21, 512) or embedding.dtype != np.float32 or not np.isfinite(embedding).all():
            raise RuntimeError(f"invalid resumable CLIP cache case: {case_path}")
        completed_ids.add(case_id)
    atomic_json(manifest_path, {**identity, "completed_case_count": len(completed_ids), "resumed": bool(args.resume)})
    os.environ["HF_HUB_OFFLINE"] = "1"
    os.environ["TRANSFORMERS_OFFLINE"] = "1"
    device = torch.device("cuda:0" if args.device == "cuda" and torch.cuda.is_available() else "cpu")
    encoder_files = verify_clip_root(args.clip_model_root)
    processor = CLIPProcessor.from_pretrained(str(args.clip_model_root), local_files_only=True)
    model = CLIPModel.from_pretrained(str(args.clip_model_root), local_files_only=True).eval().to(device)
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    started = time.time()
    try:
        for case_id in case_ids:
            if case_id in completed_ids:
                continue
            rgb_path = args.rgb_root / f"shard_{case_id % args.shard_count}" / "cases" / f"case_{case_id:04d}.npz"
            with np.load(rgb_path, allow_pickle=False) as payload:
                pixels = payload["pixels"]
            if pixels.shape != (21, 32, 32, 3) or pixels.dtype != np.uint8:
                raise RuntimeError(f"invalid RGB source cache case: {rgb_path}")
            images = [Image.fromarray(image, mode="RGB") for image in pixels]
            inputs = processor(images=images, return_tensors="pt")
            inputs = {key: value.to(device) for key, value in inputs.items()}
            with torch.no_grad():
                embedding = model.get_image_features(pixel_values=inputs["pixel_values"])
                embedding = torch.nn.functional.normalize(embedding.float(), dim=-1)
            array = embedding.cpu().numpy().astype(np.float32)
            atomic_npz(args.output_root / "cases" / f"case_{case_id:04d}.npz", clip_embedding=array)
            completed_ids.add(case_id)
            atomic_json(manifest_path, {**identity, "completed_case_count": len(completed_ids), "last_completed_case_id": case_id, "elapsed_seconds": time.time() - started, "resumed": bool(args.resume)})
        atomic_json(manifest_path, {**identity, "status": "completed", "completed_case_count": len(case_ids), "elapsed_seconds": time.time() - started, "resumed": bool(args.resume), "encoder_files": encoder_files})
    except Exception as error:
        atomic_json(manifest_path, {**identity, "status": "failed", "completed_case_count": len(completed_ids), "error": repr(error), "traceback": traceback.format_exc(), "resumed": bool(args.resume)})
        raise
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
