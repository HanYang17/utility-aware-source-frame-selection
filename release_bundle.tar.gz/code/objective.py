"""Top-1 selection and centered downstream-utility regression."""

from __future__ import annotations

from typing import Dict, Tuple

import torch
import torch.nn.functional as F


def select_top1(scores: torch.Tensor) -> torch.Tensor:
    """Return the maximum-utility candidate index for each case."""
    if scores.ndim != 2:
        raise ValueError("scores must have shape [batch, candidates]")
    return scores.argmax(dim=1, keepdim=True)


def psnr_utility_objective(
    scores: torch.Tensor, quality_db: torch.Tensor, config: Dict[str, float]
) -> Tuple[torch.Tensor, Dict[str, float]]:
    """Regress candidate-centered downstream PSNR with Smooth-L1 loss."""
    if scores.shape != quality_db.shape:
        raise ValueError("scores and quality_db must have the same shape")
    centered_quality = quality_db - quality_db.mean(dim=1, keepdim=True)
    centered_scores = scores - scores.mean(dim=1, keepdim=True)
    beta = float(config.get("smooth_l1_beta_db", 1.0))
    if beta <= 0:
        raise ValueError("smooth_l1_beta_db must be positive")
    regression = F.smooth_l1_loss(centered_scores, centered_quality, beta=beta)
    total = float(config.get("utility_regression_weight", 1.0)) * regression
    parts = {"utility_regression": float(regression.detach())}

    parts["total"] = float(total.detach())
    return total, parts
