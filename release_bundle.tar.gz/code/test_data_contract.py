#!/usr/bin/env python3
"""Synthetic manifest checks for semantic and RGB caches."""

from __future__ import annotations

import json
import tempfile
from pathlib import Path

from cache_contract import (
    validate_aligned_rgb_cache,
    validate_clip_cache,
    validate_semantic_cache,
)
from encoder_identity import expected_encoder_files


def write(path: Path, payload) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload), encoding="utf-8")


def main() -> int:
    plan_sha = "p" * 64
    semantic_config_sha = "s" * 64
    pixel_config_sha = "c" * 64
    clip_config_sha = "l" * 64
    dinov2_files = expected_encoder_files("dinov2")
    clip_files = expected_encoder_files("clip")
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        semantic = root / "semantic"
        pixels = root / "pixels"
        clip = root / "clip"
        for shard in range(2):
            case_ids = [case_id for case_id in range(2900) if case_id % 2 == shard]
            write(semantic / f"shard_{shard}" / "manifest.json", {
                "schema": "reference-selector-semantic-cache.v1",
                "status": "completed",
                "official_test_accessed": False,
                "shard_id": shard,
                "shard_count": 2,
                "plan_sha256": plan_sha,
                "config_sha256": semantic_config_sha,
                "case_ids": case_ids,
                "completed_case_count": len(case_ids),
                "encoder_files": dinov2_files,
            })
            write(pixels / f"shard_{shard}" / "manifest.json", {
                "schema": "reference-selector-rgb-cache.v1",
                "status": "completed",
                "official_test_accessed": False,
                "official_test_gt_accessed": False,
                "candidate_psnr_accessed": False,
                "resolution": 32,
                "shard_id": shard,
                "shard_count": 2,
                "plan_sha256": plan_sha,
                "config_sha256": pixel_config_sha,
                "case_ids": case_ids,
                "completed_case_count": len(case_ids),
                "encoder_files": dinov2_files,
            })
            write(clip / f"shard_{shard}" / "manifest.json", {
                "schema": "reference-selector-clip-cache.v1",
                "status": "completed",
                "official_test_accessed": False,
                "test_gt_accessed": False,
                "candidate_psnr_accessed": False,
                "embedding_dimension": 512,
                "shard_id": shard,
                "shard_count": 2,
                "plan_sha256": plan_sha,
                "config_sha256": clip_config_sha,
                "case_ids": case_ids,
                "completed_case_count": len(case_ids),
                "encoder_files": clip_files,
            })
        validate_semantic_cache(semantic, 2, plan_sha, semantic_config_sha)
        validate_aligned_rgb_cache(pixels, 2, plan_sha, pixel_config_sha)
        validate_clip_cache(clip, 2, plan_sha, clip_config_sha)

        broken = json.loads(
            (pixels / "shard_0" / "manifest.json").read_text(encoding="utf-8")
        )
        broken["candidate_psnr_accessed"] = True
        write(pixels / "shard_0" / "manifest.json", broken)
        try:
            validate_aligned_rgb_cache(pixels, 2, plan_sha, pixel_config_sha)
        except RuntimeError as error:
            if "invalid RGB cache manifest" not in str(error):
                raise
        else:
            raise RuntimeError("privileged RGB cache was not rejected")
    print("cache contract tests passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
