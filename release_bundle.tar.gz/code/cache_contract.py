"""Manifest validation for semantic, RGB, and CLIP feature caches."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List

from encoder_identity import expected_encoder_files


def validate_semantic_cache(
    root: Path,
    shard_count: int,
    plan_sha256: str,
    config_sha256: str,
) -> List[Dict[str, Any]]:
    manifests: List[Dict[str, Any]] = []
    expected_dinov2 = expected_encoder_files("dinov2")
    covered: set[int] = set()
    for shard_id in range(shard_count):
        path = root / f"shard_{shard_id}" / "manifest.json"
        payload = json.loads(path.read_text(encoding="utf-8"))
        expected = {
            "schema": "reference-selector-semantic-cache.v1",
            "status": "completed",
            "official_test_accessed": False,
            "shard_id": shard_id,
            "shard_count": shard_count,
            "plan_sha256": plan_sha256,
            "config_sha256": config_sha256,
            "encoder_files": expected_dinov2,
        }
        actual = {
            "schema": payload.get("schema"),
            "status": payload.get("status"),
            "official_test_accessed": payload.get("official_test_accessed"),
            "shard_id": payload.get("shard_id"),
            "shard_count": payload.get("shard_count"),
            "plan_sha256": payload.get("plan_sha256"),
            "config_sha256": payload.get("config_sha256"),
            "encoder_files": payload.get("encoder_files"),
        }
        mismatches = {
            key: {"expected": expected[key], "actual": actual[key]}
            for key in expected
            if actual[key] != expected[key]
        }
        if mismatches:
            raise RuntimeError(
                f"invalid semantic cache manifest: {path}; mismatches={mismatches}"
            )
        ids = {int(value) for value in payload["case_ids"]}
        expected = {
            case_id for case_id in range(2900)
            if case_id % shard_count == shard_id
        }
        if ids != expected or int(payload.get("completed_case_count", -1)) != len(expected):
            raise RuntimeError(f"incomplete semantic cache shard: {path}")
        covered.update(ids)
        manifests.append(payload)
    if covered != set(range(2900)):
        raise RuntimeError("semantic cache does not cover exactly 2,900 cases")
    return manifests


def validate_aligned_rgb_cache(
    root: Path,
    shard_count: int,
    plan_sha256: str,
    config_sha256: str,
) -> List[Dict[str, Any]]:
    manifests: List[Dict[str, Any]] = []
    expected_dinov2 = expected_encoder_files("dinov2")
    covered: set[int] = set()
    for shard_id in range(shard_count):
        path = root / f"shard_{shard_id}" / "manifest.json"
        payload = json.loads(path.read_text(encoding="utf-8"))
        if (
            payload.get("schema") != "reference-selector-rgb-cache.v1"
            or payload.get("status") != "completed"
            or int(payload.get("shard_id", -1)) != shard_id
            or int(payload.get("shard_count", -1)) != shard_count
            or int(payload.get("resolution", -1)) != 32
            or payload.get("plan_sha256") != plan_sha256
            or payload.get("config_sha256") != config_sha256
            or payload.get("official_test_accessed") is not False
            or payload.get("official_test_gt_accessed") is not False
            or payload.get("candidate_psnr_accessed") is not False
            or payload.get("encoder_files") != expected_dinov2
        ):
            raise RuntimeError(f"invalid RGB cache manifest: {path}")
        ids = {int(value) for value in payload["case_ids"]}
        expected = {
            case_id for case_id in range(2900)
            if case_id % shard_count == shard_id
        }
        if ids != expected or int(payload["completed_case_count"]) != len(expected):
            raise RuntimeError(f"incomplete RGB cache shard: {path}")
        covered.update(ids)
        manifests.append(payload)
    if covered != set(range(2900)):
        raise RuntimeError("RGB cache does not cover exactly 2,900 cases")
    return manifests


def validate_clip_cache(
    root: Path,
    shard_count: int,
    plan_sha256: str,
    config_sha256: str,
) -> List[Dict[str, Any]]:
    manifests: List[Dict[str, Any]] = []
    expected_clip = expected_encoder_files("clip")
    covered: set[int] = set()
    for shard_id in range(shard_count):
        path = root / f"shard_{shard_id}" / "manifest.json"
        payload = json.loads(path.read_text(encoding="utf-8"))
        expected_ids = {
            case_id for case_id in range(2900) if case_id % shard_count == shard_id
        }
        if (
            payload.get("schema") != "reference-selector-clip-cache.v1"
            or payload.get("status") != "completed"
            or int(payload.get("shard_id", -1)) != shard_id
            or int(payload.get("shard_count", -1)) != shard_count
            or int(payload.get("embedding_dimension", -1)) != 512
            or payload.get("plan_sha256") != plan_sha256
            or payload.get("config_sha256") != config_sha256
            or payload.get("official_test_accessed") is not False
            or payload.get("test_gt_accessed") is not False
            or payload.get("candidate_psnr_accessed") is not False
            or payload.get("encoder_files") != expected_clip
        ):
            raise RuntimeError(f"invalid CLIP cache manifest: {path}")
        ids = {int(value) for value in payload["case_ids"]}
        if ids != expected_ids or int(payload.get("completed_case_count", -1)) != len(ids):
            raise RuntimeError(f"incomplete CLIP cache shard: {path}")
        covered.update(ids)
        manifests.append(payload)
    if covered != set(range(2900)):
        raise RuntimeError("CLIP cache does not cover exactly 2,900 cases")
    return manifests
