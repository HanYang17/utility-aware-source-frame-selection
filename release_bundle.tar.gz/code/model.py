"""Reference-frame selector with content, local-color, and global-context cues."""

from __future__ import annotations

from typing import Any, Dict

import torch
import torch.nn as nn


class ConvColorEncoder(nn.Module):
    """Encode aligned low-resolution RGB into an 8x8 grid of color tokens."""

    def __init__(self, token_dimension: int = 32) -> None:
        super().__init__()
        if token_dimension != 32:
            raise ValueError("the color token dimension must be 32")
        self.stem = nn.Sequential(
            nn.Conv2d(3, 16, kernel_size=3, padding=1),
            nn.GroupNorm(4, 16),
            nn.GELU(),
            nn.Conv2d(16, 32, kernel_size=3, stride=2, padding=1),
            nn.GroupNorm(8, 32),
            nn.GELU(),
            nn.Conv2d(32, 32, kernel_size=3, stride=2, padding=1),
            nn.GroupNorm(8, 32),
            nn.GELU(),
        )
        self.refine = nn.Sequential(
            nn.Conv2d(32, 32, kernel_size=3, padding=1),
            nn.GroupNorm(8, 32),
            nn.GELU(),
            nn.Conv2d(32, 32, kernel_size=3, padding=1),
        )
        self.output_norm = nn.LayerNorm(32)

    def forward(self, pixels: torch.Tensor) -> torch.Tensor:
        if pixels.ndim != 4 or pixels.shape[-1] != 3:
            raise ValueError("pixels must have shape [images, height, width, 3]")
        if pixels.shape[1:3] != (32, 32):
            raise ValueError("RGB inputs must have spatial resolution 32x32")
        if torch.is_floating_point(pixels):
            values = pixels.float()
        else:
            values = pixels.float().div(255.0)
        values = values.permute(0, 3, 1, 2).contiguous()
        encoded = self.stem(values)
        encoded = encoded + self.refine(encoded)
        tokens = encoded.permute(0, 2, 3, 1).reshape(len(encoded), 64, 32)
        return self.output_norm(tokens)


class ReferenceFrameUtilityModel(nn.Module):
    """Predict one continuous utility score for each of 20 candidate frames."""

    def __init__(self, config: Dict[str, Any]) -> None:
        super().__init__()
        feature = config["features"]
        model = config["model"]
        semantic_dimension = int(feature["semantic_dimension"])
        projection = int(feature["semantic_projection_dimension"])
        color_dimension = int(feature["color_token_dimension"])
        clip_dimension = int(feature["clip_embedding_dimension"])
        clip_projection = int(feature["clip_projection_dimension"])
        relation_dimension = int(feature["relation_dimension"])
        if int(feature["color_input_resolution"]) != 32:
            raise ValueError("the RGB input resolution must be 32")
        self.semantic_projection = nn.Sequential(
            nn.LayerNorm(semantic_dimension),
            nn.Linear(semantic_dimension, projection),
            nn.GELU(),
            nn.Linear(projection, projection),
        )
        self.color_encoder = ConvColorEncoder(color_dimension)
        self.clip_projection = nn.Sequential(
            nn.LayerNorm(clip_dimension),
            nn.Linear(clip_dimension, clip_projection),
            nn.GELU(),
            nn.Linear(clip_projection, clip_projection),
        )
        self.cross_attention = nn.MultiheadAttention(
            projection,
            int(model["cross_attention_heads"]),
            dropout=0.0,
            batch_first=True,
        )
        relation_input = projection * 4 + color_dimension * 4 + clip_projection * 4
        self.patch_relation = nn.Sequential(
            nn.LayerNorm(relation_input),
            nn.Linear(relation_input, relation_dimension),
            nn.GELU(),
            nn.Linear(relation_dimension, relation_dimension),
        )
        query_count = int(model["patch_pool_queries"])
        self.pool_queries = nn.Parameter(
            torch.randn(query_count, relation_dimension) * 0.02
        )
        self.patch_pool = nn.MultiheadAttention(
            relation_dimension, 8, dropout=0.0, batch_first=True
        )
        self.candidate_projection = nn.Sequential(
            nn.LayerNorm(query_count * relation_dimension),
            nn.Linear(query_count * relation_dimension, relation_dimension),
            nn.GELU(),
            nn.Linear(relation_dimension, relation_dimension),
        )
        layer = nn.TransformerEncoderLayer(
            d_model=relation_dimension,
            nhead=int(model["set_attention_heads"]),
            dim_feedforward=int(model["set_feed_forward_dimension"]),
            dropout=float(model["dropout"]),
            activation="gelu",
            batch_first=True,
            norm_first=True,
        )
        self.set_encoder = nn.TransformerEncoder(
            layer, num_layers=int(model["set_layers"])
        )
        hidden = int(model["utility_head_hidden"])
        self.utility_head = nn.Sequential(
            nn.LayerNorm(relation_dimension),
            nn.Linear(relation_dimension, hidden),
            nn.GELU(),
            nn.Linear(hidden, 1),
        )

    @staticmethod
    def _validate_semantic_inputs(
        candidate: torch.Tensor, reference: torch.Tensor
    ) -> tuple[int, int, int]:
        if candidate.ndim != 4 or reference.ndim != 3:
            raise ValueError("semantic inputs must be [B,C,P,D] and [B,P,D]")
        batch, candidates, patches, dimension = candidate.shape
        if candidates != 20 or patches != 64:
            raise ValueError("semantic inputs must contain 20 candidates and 64 patches")
        if reference.shape != (batch, patches, dimension):
            raise ValueError("candidate/reference semantic shapes do not align")
        return batch, candidates, patches

    @staticmethod
    def _validate_pixel_inputs(
        candidate: torch.Tensor,
        reference: torch.Tensor,
        batch: int,
        candidates: int,
    ) -> None:
        if candidate.shape != (batch, candidates, 32, 32, 3):
            raise ValueError("candidate pixels must be [B,20,32,32,3]")
        if reference.shape != (batch, 32, 32, 3):
            raise ValueError("reference pixels must be [B,32,32,3]")

    @staticmethod
    def _validate_clip_inputs(
        candidate: torch.Tensor,
        reference: torch.Tensor,
        batch: int,
        candidates: int,
    ) -> None:
        if candidate.shape != (batch, candidates, 512):
            raise ValueError("candidate CLIP embeddings must be [B,20,512]")
        if reference.shape != (batch, 512):
            raise ValueError("reference CLIP embeddings must be [B,512]")

    def forward(
        self,
        candidate_semantic: torch.Tensor,
        candidate_pixels: torch.Tensor,
        reference_semantic: torch.Tensor,
        reference_pixels: torch.Tensor,
        candidate_clip: torch.Tensor,
        reference_clip: torch.Tensor,
    ) -> torch.Tensor:
        batch, candidates, patches = self._validate_semantic_inputs(
            candidate_semantic, reference_semantic
        )
        self._validate_pixel_inputs(
            candidate_pixels, reference_pixels, batch, candidates
        )
        self._validate_clip_inputs(candidate_clip, reference_clip, batch, candidates)
        candidate_s = self.semantic_projection(
            candidate_semantic.reshape(batch * candidates, patches, -1)
        )
        reference_s = self.semantic_projection(reference_semantic)
        reference_s = (
            reference_s[:, None]
            .expand(-1, candidates, -1, -1)
            .reshape(batch * candidates, patches, -1)
        )
        matched_s, weights = self.cross_attention(
            candidate_s, reference_s, reference_s, need_weights=True
        )

        candidate_c = self.color_encoder(
            candidate_pixels.reshape(batch * candidates, 32, 32, 3)
        )
        reference_c = self.color_encoder(reference_pixels)
        reference_c = (
            reference_c[:, None]
            .expand(-1, candidates, -1, -1)
            .reshape(batch * candidates, patches, -1)
        )
        matched_c = torch.bmm(weights, reference_c)
        candidate_a = self.clip_projection(candidate_clip)
        candidate_a = (
            candidate_a[:, :, None, :]
            .expand(-1, -1, patches, -1)
            .reshape(batch * candidates, patches, -1)
        )
        reference_a = self.clip_projection(reference_clip)
        reference_a = (
            reference_a[:, None, None, :]
            .expand(-1, candidates, patches, -1)
            .reshape(batch * candidates, patches, -1)
        )
        relation = torch.cat(
            [
                candidate_s,
                matched_s,
                candidate_s - matched_s,
                candidate_s * matched_s,
                candidate_c,
                matched_c,
                candidate_c - matched_c,
                candidate_c * matched_c,
                candidate_a,
                reference_a,
                candidate_a - reference_a,
                candidate_a * reference_a,
            ],
            dim=-1,
        )
        relation = self.patch_relation(relation)
        queries = self.pool_queries[None].expand(batch * candidates, -1, -1)
        pooled, _ = self.patch_pool(queries, relation, relation, need_weights=False)
        token = self.candidate_projection(pooled.reshape(batch, candidates, -1))
        token = self.set_encoder(token)
        return self.utility_head(token).squeeze(-1)
