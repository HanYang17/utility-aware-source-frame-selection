#!/usr/bin/env python3
"""Standard-library tests for exact encoder-file identity verification."""

from __future__ import annotations

import hashlib
import json
import tempfile
from pathlib import Path

from encoder_identity import verify_encoder_root


def main() -> int:
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        model_root = root / "model"
        model_root.mkdir()
        model_file = model_root / "weights.bin"
        model_file.write_bytes(b"verified weights")
        expected = hashlib.sha256(model_file.read_bytes()).hexdigest()
        identity_path = root / "identities.json"
        identity_path.write_text(
            json.dumps({
                "schema": "reference-frame-selector-encoder-identities.v1",
                "test": {"files": {"weights.bin": expected}},
            }) + "\n",
            encoding="utf-8",
        )
        verified = verify_encoder_root("test", model_root, identity_path)
        if verified != {"weights.bin": expected}:
            raise RuntimeError("valid encoder identity was not returned")
        model_file.write_bytes(b"changed weights")
        try:
            verify_encoder_root("test", model_root, identity_path)
        except RuntimeError as error:
            if "identity mismatch" not in str(error):
                raise
        else:
            raise RuntimeError("modified encoder file was not rejected")
    print("encoder-identity tests passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
