#!/usr/bin/env python3
"""Train the reference-frame utility model on all 2,900 training cases."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import random
from pathlib import Path
from typing import Any, Dict, List

import numpy as np
import torch
from torch.utils.data import DataLoader

from data import (
    AlignedPixelDataset,
    validate_aligned_rgb_cache,
    validate_clip_cache,
    validate_semantic_cache,
)
from model import ReferenceFrameUtilityModel
from objective import psnr_utility_objective
from protocol import validate_training_contract


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def atomic_json(path: Path, payload: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    partial = path.with_suffix(path.suffix + ".partial")
    partial.write_text(
        json.dumps(payload, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )
    os.replace(partial, path)


def atomic_torch(path: Path, payload: Dict[str, Any]) -> None:
    partial = path.with_suffix(path.suffix + ".partial")
    torch.save(payload, partial)
    os.replace(partial, path)


@torch.no_grad()
def evaluate_train(
    model: ReferenceFrameUtilityModel,
    loader: DataLoader,
    device: torch.device,
) -> Dict[str, float]:
    model.eval()
    score_rows: List[np.ndarray] = []
    quality_rows: List[np.ndarray] = []
    clip_rows: List[np.ndarray] = []
    for batch in loader:
        score = model(
            batch["candidate_semantic"].to(device),
            batch["candidate_pixels"].to(device),
            batch["reference_semantic"].to(device),
            batch["reference_pixels"].to(device),
            batch["candidate_clip"].to(device),
            batch["reference_clip"].to(device),
        )
        score_rows.append(score.cpu().numpy())
        quality_rows.append(batch["quality"].numpy())
        clip_rows.append(batch["clip_position"].numpy())
    score = np.concatenate(score_rows).astype(np.float64)
    quality = np.concatenate(quality_rows).astype(np.float64)
    clip = np.concatenate(clip_rows).astype(np.int64)
    selected = score.argmax(axis=1)
    row = np.arange(len(selected))
    true_order = np.argsort(-quality, axis=1, kind="stable")
    true_rank = np.argsort(true_order, axis=1, kind="stable") + 1
    gain = quality[row, selected] - quality[row, clip]
    regret = quality.max(axis=1) - quality[row, selected]
    return {
        "case_count": int(len(selected)),
        "train_top1_hit_rate": float(np.mean(true_rank[row, selected] == 1)),
        "train_within_true_top3_rate": float(np.mean(true_rank[row, selected] <= 3)),
        "train_mean_psnr_gain_vs_vcg_label_db": float(gain.mean()),
        "train_mean_oracle_regret_db": float(regret.mean()),
        "train_severe_regression_rate_vs_vcg_label": float(np.mean(gain <= -0.5)),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--labels", type=Path, required=True)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--semantic-cache-root", type=Path, required=True)
    parser.add_argument("--semantic-cache-shards", type=int, required=True)
    parser.add_argument("--semantic-cache-config-sha256", required=True)
    parser.add_argument("--pixel-cache-root", type=Path, required=True)
    parser.add_argument("--pixel-cache-shards", type=int, required=True)
    parser.add_argument("--clip-cache-root", type=Path, required=True)
    parser.add_argument("--clip-cache-shards", type=int, required=True)
    parser.add_argument("--clip-cache-config-sha256", required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    args = parser.parse_args()
    if not torch.cuda.is_available() or torch.cuda.device_count() != 1:
        raise RuntimeError("exactly one CUDA-visible GPU is required")
    if args.output_root.exists():
        raise RuntimeError(f"refusing to overwrite full-training result: {args.output_root}")
    args.output_root.mkdir(parents=True)

    config = json.loads(args.config.read_text(encoding="utf-8"))
    data_config = config["data"]
    config_sha256 = sha256_file(args.config)
    if (
        config.get("status") != "final_method_configuration"
        or data_config.get("official_test_accessed") is not False
        or data_config.get("test_ground_truth_as_model_input") is not False
        or data_config.get("candidate_psnr_as_model_input") is not False
        or sha256_file(args.labels) != data_config["labels_sha256"]
        or sha256_file(args.plan) != data_config["plan_sha256"]
    ):
        raise RuntimeError("invalid full-training contract")
    validate_semantic_cache(
        args.semantic_cache_root,
        args.semantic_cache_shards,
        data_config["plan_sha256"],
        data_config.get("semantic_cache_source_config_sha256", args.semantic_cache_config_sha256),
    )
    validate_aligned_rgb_cache(
        args.pixel_cache_root,
        args.pixel_cache_shards,
        data_config["plan_sha256"],
        data_config.get("rgb_cache_source_config_sha256", config_sha256),
    )
    validate_clip_cache(
        args.clip_cache_root,
        args.clip_cache_shards,
        data_config["plan_sha256"],
        args.clip_cache_config_sha256,
    )
    plan_payload = json.loads(args.plan.read_text(encoding="utf-8"))
    with np.load(args.labels, allow_pickle=False) as payload:
        quality = payload["quality_psnr_db"].astype(np.float32)
        clip_position = payload["clip_position"].astype(np.int64)
        case_fold = payload["case_fold"].astype(np.int64)
    split_audit = validate_training_contract(
        plan_payload, quality, clip_position, case_fold
    )

    training = config["training"]
    epoch_count = int(training["full_training_epochs"])
    if epoch_count < 1:
        raise RuntimeError("full_training_epochs must be positive")
    seed = int(config["seed"])
    set_seed(seed)
    case_ids = list(range(2900))
    train_dataset = AlignedPixelDataset(
        args.semantic_cache_root,
        args.semantic_cache_shards,
        args.pixel_cache_root,
        args.pixel_cache_shards,
        args.clip_cache_root,
        args.clip_cache_shards,
        case_ids,
        quality,
        clip_position,
        True,
    )
    train_loader = DataLoader(
        train_dataset,
        batch_size=int(training["batch_size"]),
        shuffle=True,
        generator=torch.Generator().manual_seed(seed),
        num_workers=0,
    )
    eval_loader = DataLoader(
        AlignedPixelDataset(
            args.semantic_cache_root,
            args.semantic_cache_shards,
            args.pixel_cache_root,
            args.pixel_cache_shards,
            args.clip_cache_root,
            args.clip_cache_shards,
            case_ids,
            quality,
            clip_position,
            False,
        ),
        batch_size=int(training["evaluation_batch_size"]),
        shuffle=False,
        num_workers=0,
    )
    device = torch.device("cuda:0")
    model = ReferenceFrameUtilityModel(config).to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=float(training["learning_rate"]),
        weight_decay=float(training["weight_decay"]),
    )
    trace: List[Dict[str, Any]] = []
    for epoch in range(1, epoch_count + 1):
        model.train()
        parts: List[Dict[str, float]] = []
        for batch in train_loader:
            optimizer.zero_grad(set_to_none=True)
            score = model(
                batch["candidate_semantic"].to(device),
                batch["candidate_pixels"].to(device),
                batch["reference_semantic"].to(device),
                batch["reference_pixels"].to(device),
                batch["candidate_clip"].to(device),
                batch["reference_clip"].to(device),
            )
            loss, row = psnr_utility_objective(
                score, batch["quality"].to(device), config["objective"]
            )
            loss.backward()
            torch.nn.utils.clip_grad_norm_(
                model.parameters(), float(training["gradient_clip_norm"])
            )
            optimizer.step()
            parts.append(row)
        trace.append({
            "epoch": epoch,
            "training_loss": {
                key: float(np.mean([row[key] for row in parts]))
                for key in parts[0]
            },
        })
        atomic_json(
            args.output_root / "training_trace.json",
            {
                "schema": "reference-selector-training-trace.v1",
                "status": "running",
                "fixed_epoch_count": epoch_count,
                "completed_epoch_count": epoch,
                "epochs": trace,
                "official_test_accessed": False,
            },
        )
    checkpoint_path = args.output_root / "final_checkpoint.pt"
    atomic_torch(checkpoint_path, {
        "model_state": model.state_dict(),
        "epoch": epoch_count,
        "config": config,
        "provenance": {"configuration": "final_method"},
    })
    metrics = evaluate_train(model, eval_loader, device)
    result = {
        "schema": "reference-selector-training.v1",
        "status": "completed",
        "train_case_count": 2900,
        "fixed_epoch_count": epoch_count,
        "metrics": metrics,
        "checkpoint_sha256": sha256_file(checkpoint_path),
        "input_hashes": {
            "config": config_sha256,
            "labels": sha256_file(args.labels),
            "plan": sha256_file(args.plan),
            "model": sha256_file(Path(__file__).with_name("model.py")),
            "trainer": sha256_file(Path(__file__).resolve()),
        },
        "protocol": {
            "official_test_accessed": False,
            "test_gt_as_model_input": False,
            "candidate_psnr_used_only_as_training_supervision": True,
            "epoch_count_fixed_by_configuration": True,
            "training_split_audit": split_audit,
        },
    }
    atomic_json(args.output_root / "evaluation.json", result)
    atomic_json(
        args.output_root / "training_trace.json",
        {
            "schema": "reference-selector-training-trace.v1",
            "status": "completed",
            "fixed_epoch_count": epoch_count,
            "completed_epoch_count": epoch_count,
            "epochs": trace,
            "official_test_accessed": False,
        },
    )
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
