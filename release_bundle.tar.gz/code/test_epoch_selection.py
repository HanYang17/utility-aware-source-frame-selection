#!/usr/bin/env python3
"""Standard-library tests for five-fold epoch selection."""

from __future__ import annotations

import hashlib
import json
import subprocess
import sys
import tempfile
from pathlib import Path


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    script = Path(__file__).with_name("select_training_epochs.py")
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        config = root / "config.json"
        config.write_text(
            json.dumps({"training": {"full_training_epochs": 7}}) + "\n",
            encoding="utf-8",
        )
        config_sha256 = sha256_file(config)
        evaluations = []
        for fold, epoch in enumerate((12, 7, 7, 3, 8)):
            path = root / f"fold_{fold}.json"
            path.write_text(
                json.dumps({
                    "schema": "reference-selector-validation-fold.v1",
                    "status": "completed",
                    "validation_fold": fold,
                    "best_epoch": epoch,
                    "best_validation_metrics": {"mean_selected_psnr_gain_vs_clip_db": 0.0},
                    "checkpoint_sha256": f"checkpoint-{fold}",
                    "input_hashes": {"config": config_sha256},
                    "protocol": {"official_test_accessed": False},
                }) + "\n",
                encoding="utf-8",
            )
            evaluations.append(path)
        output = root / "selection.json"
        command = [
            sys.executable, str(script), "--config", str(config), "--output", str(output)
        ]
        for path in reversed(evaluations):
            command.extend(["--evaluation", str(path)])
        subprocess.run(command, check=True, capture_output=True, text=True)
        result = json.loads(output.read_text(encoding="utf-8"))
        if result["selected_full_training_epoch"] != 7:
            raise RuntimeError("median epoch selection failed")
        if [row["validation_fold"] for row in result["folds"]] != list(range(5)):
            raise RuntimeError("fold ordering failed")
        duplicate = subprocess.run(command, capture_output=True, text=True)
        if duplicate.returncode == 0 or "refusing to overwrite" not in duplicate.stderr:
            raise RuntimeError("duplicate-output rejection failed")
    print("epoch-selection tests passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
