#!/usr/bin/env python3
"""Extract DINO-aligned RGB for the 100-case VCG test index."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import time
import traceback
from pathlib import Path
from typing import Any, Dict, List

import cv2
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from transformers import AutoImageProcessor

from encoder_identity import verify_dinov2_root


CANDIDATE_INDICES = list(range(0, 480, 24))


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def atomic_json(path: Path, payload: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    partial = path.with_suffix(path.suffix + ".partial")
    partial.write_text(
        json.dumps(payload, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )
    os.replace(partial, path)


def atomic_npz(path: Path, **arrays: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    partial = path.with_suffix(path.suffix + ".partial")
    with partial.open("wb") as handle:
        np.savez_compressed(handle, **arrays)
    os.replace(partial, path)


def read_selected_frames(path: Path, indices: List[int]) -> Dict[int, np.ndarray]:
    wanted = set(indices)
    capture = cv2.VideoCapture(str(path))
    if not capture.isOpened():
        raise RuntimeError(f"cannot open video: {path}")
    frames: Dict[int, np.ndarray] = {}
    try:
        frame_index = 0
        while frame_index <= max(wanted):
            ok, frame = capture.read()
            if not ok:
                raise RuntimeError(f"decode stopped at frame {frame_index}: {path}")
            if frame_index in wanted:
                frames[frame_index] = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            frame_index += 1
    finally:
        capture.release()
    if set(frames) != wanted:
        raise RuntimeError(f"missing frames: {sorted(wanted - set(frames))}")
    return frames


def validate_index(path: Path, expected_sha256: str) -> List[Dict[str, Any]]:
    if sha256_file(path) != expected_sha256:
        raise RuntimeError("official test index SHA256 mismatch")
    payload = json.loads(path.read_text(encoding="utf-8"))
    rows = payload.get("cases", [])
    if (
        payload.get("schema") != "direction1_condensed_index.v1"
        or len(rows) != 100
        or [int(row.get("global_index", -1)) for row in rows] != list(range(100))
    ):
        raise RuntimeError("official test index must cover ordered case IDs 0..99")
    return rows


def aligned_pixels(processor: Any, images: List[np.ndarray]) -> np.ndarray:
    values = processor(images=images, return_tensors="pt").pixel_values.float()
    mean = torch.tensor(processor.image_mean)[None, :, None, None]
    std = torch.tensor(processor.image_std)[None, :, None, None]
    rgb = (values * std + mean).clamp(0.0, 1.0)
    rgb = F.interpolate(rgb, size=(32, 32), mode="area")
    result = (
        rgb.mul(255.0)
        .round()
        .clamp(0.0, 255.0)
        .to(torch.uint8)
        .permute(0, 2, 3, 1)
        .contiguous()
        .numpy()
    )
    if result.shape != (21, 32, 32, 3):
        raise RuntimeError(f"unexpected test RGB shape: {result.shape}")
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--index", type=Path, required=True)
    parser.add_argument("--expected-index-sha256", required=True)
    parser.add_argument("--model-root", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    args = parser.parse_args()
    manifest_path = args.output_root / "shard_0" / "manifest.json"
    if manifest_path.exists():
        raise RuntimeError(f"refusing to overwrite test RGB cache: {manifest_path}")
    rows = validate_index(args.index, args.expected_index_sha256)
    identity = {
        "schema": "reference-selector-rgb-test-cache.v1",
        "status": "running",
        "case_ids": list(range(100)),
        "case_count": 100,
        "candidate_count_per_case": 20,
        "candidate_indices": CANDIDATE_INDICES,
        "resolution": 32,
        "shard_id": 0,
        "shard_count": 1,
        "index_sha256": args.expected_index_sha256,
        "processor_model_root": str(args.model_root.resolve()),
        "official_test_accessed": True,
        "test_gt_accessed": False,
        "test_gt_as_model_input": False,
        "target_lut_accessed": False,
        "candidate_psnr_accessed": False,
    }
    atomic_json(manifest_path, {**identity, "completed_case_count": 0})
    os.environ["HF_HUB_OFFLINE"] = "1"
    os.environ["TRANSFORMERS_OFFLINE"] = "1"
    encoder_files = verify_dinov2_root(args.model_root)
    processor = AutoImageProcessor.from_pretrained(
        str(args.model_root), local_files_only=True
    )
    started = time.time()
    try:
        for completed, row in enumerate(rows, start=1):
            case_id = int(row["global_index"])
            frames = read_selected_frames(Path(row["video"]), CANDIDATE_INDICES)
            candidates = [frames[index] for index in CANDIDATE_INDICES]
            reference_path = Path(row["case_root"]) / row["reference_frame"]
            reference = np.asarray(Image.open(reference_path).convert("RGB"))
            pixels = aligned_pixels(processor, candidates + [reference])
            atomic_npz(
                args.output_root / "shard_0" / "cases" / f"case_{case_id:04d}.npz",
                pixels=pixels,
            )
            atomic_json(
                manifest_path,
                {
                    **identity,
                    "completed_case_count": completed,
                    "last_completed_case_id": case_id,
                    "elapsed_seconds": time.time() - started,
                },
            )
        atomic_json(
            manifest_path,
            {
                **identity,
                "status": "completed",
                "completed_case_count": 100,
                "elapsed_seconds": time.time() - started,
                "encoder_files": encoder_files,
            },
        )
    except Exception as error:
        atomic_json(
            manifest_path,
            {
                **identity,
                "status": "failed",
                "completed_case_count": completed - 1 if "completed" in locals() else 0,
                "error": repr(error),
                "traceback": traceback.format_exc(),
            },
        )
        raise
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
