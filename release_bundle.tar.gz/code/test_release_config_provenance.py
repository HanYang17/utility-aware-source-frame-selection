#!/usr/bin/env python3
"""Verify release-config identity and scientific-field provenance."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Mapping


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def verify_subset(actual: Mapping[str, Any], expected: Mapping[str, Any], prefix: str = "") -> None:
    for key, value in expected.items():
        path = f"{prefix}.{key}" if prefix else key
        if key not in actual:
            raise RuntimeError(f"missing public configuration field: {path}")
        if isinstance(value, dict):
            if not isinstance(actual[key], dict):
                raise RuntimeError(f"configuration field is not an object: {path}")
            verify_subset(actual[key], value, path)
        elif actual[key] != value:
            raise RuntimeError(
                f"configuration mismatch at {path}: {actual[key]!r} != {value!r}"
            )


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    config_path = root / "config" / "selector_config.json"
    provenance_path = root / "metadata" / "config_provenance.json"
    epoch_path = root / "metadata" / "epoch_selection.json"

    config = json.loads(config_path.read_text(encoding="utf-8"))
    provenance = json.loads(provenance_path.read_text(encoding="utf-8"))
    epoch = json.loads(epoch_path.read_text(encoding="utf-8"))

    if provenance.get("schema") != "reference-selector-config-provenance.v1":
        raise RuntimeError("invalid config-provenance schema")
    if provenance.get("status") != "verified":
        raise RuntimeError("config provenance is not verified")
    if provenance.get("relationship", {}).get("scientific_parameter_equivalence") is not True:
        raise RuntimeError("scientific parameter equivalence is not asserted")

    public_hash = sha256_file(config_path)
    declared_public_hash = provenance["public_release_config"]["sha256"]
    if public_hash != declared_public_hash:
        raise RuntimeError("public release configuration hash mismatch")
    if epoch.get("public_release_config_sha256") != public_hash:
        raise RuntimeError("epoch evidence does not bind the public release configuration")

    executed_hash = provenance["executed_training_config"]["sha256"]
    if epoch.get("executed_training_config_sha256") != executed_hash:
        raise RuntimeError("epoch evidence does not bind the executed training configuration")
    if epoch.get("scientific_parameter_equivalence") is not True:
        raise RuntimeError("epoch evidence does not assert scientific equivalence")

    verify_subset(config, provenance["scientific_contract"])

    training = config["training"]
    data = config["data"]
    if epoch["selected_full_training_epoch"] != training["full_training_epochs"]:
        raise RuntimeError("selected epoch does not match the public training configuration")
    if epoch["validation_best_epochs"] != training["validation_best_epochs"]:
        raise RuntimeError("validation epochs do not match the public training configuration")
    if epoch["maximum_validation_epochs"] != training["maximum_validation_epochs"]:
        raise RuntimeError("maximum validation epochs do not match")
    if epoch["early_stopping_patience"] != training["early_stopping_patience"]:
        raise RuntimeError("early-stopping patience does not match")
    if len(epoch["fold_seeds"]) != training["validation_fold_count"]:
        raise RuntimeError("validation-fold count does not match")
    if epoch["fold_seeds"][0] != config["seed"]:
        raise RuntimeError("release seed does not bind the first fold seed")
    if epoch["labels_sha256"] != data["labels_sha256"]:
        raise RuntimeError("training-label hash does not match")
    if epoch["plan_sha256"] != data["plan_sha256"]:
        raise RuntimeError("training-plan hash does not match")
    if sum(epoch["fold_case_counts"]) != data["train_case_count"]:
        raise RuntimeError("validation-fold case counts do not cover the training set")
    if sum(epoch["fold_lut_counts"]) != 87:
        raise RuntimeError("validation-fold LUT counts do not cover the training LUTs")
    if epoch.get("official_test_accessed") is not False:
        raise RuntimeError("official test was used for epoch selection")

    print("release-config provenance tests passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
