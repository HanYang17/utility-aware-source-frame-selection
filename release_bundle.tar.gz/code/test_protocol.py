#!/usr/bin/env python3
"""Synthetic checks for the full-train and LUT-isolated split contract."""

from __future__ import annotations

import numpy as np

from protocol import validate_training_contract


def fixtures():
    train_lut_ids = np.asarray(
        list(range(1, 47)) + list(range(50, 91)), dtype=np.int64
    )
    lut = np.resize(train_lut_ids, 2900)
    fold_by_lut = {
        int(lut_id): index % 5 for index, lut_id in enumerate(train_lut_ids)
    }
    folds = np.asarray([fold_by_lut[int(value)] for value in lut], dtype=np.int64)
    plan = {
        "case_count": 2900,
        "candidate_count_per_case": 20,
        "final_test_gt_accessed": False,
        "cases": [
            {"case_id": case_id, "target_lut_id": int(lut[case_id])}
            for case_id in range(2900)
        ],
    }
    quality = np.zeros((2900, 20), dtype=np.float32)
    clip = np.zeros(2900, dtype=np.int64)
    return plan, quality, clip, folds


def main() -> int:
    plan, quality, clip, folds = fixtures()
    audit = validate_training_contract(plan, quality, clip, folds)
    if audit["cross_fold_lut_overlap_count"] != 0:
        raise RuntimeError("valid LUT-isolated split was not accepted")

    leaking = folds.copy()
    leaking[90] = (int(leaking[90]) + 1) % 5
    try:
        validate_training_contract(plan, quality, clip, leaking)
    except RuntimeError as error:
        if "leaks across folds" not in str(error):
            raise
    else:
        raise RuntimeError("cross-fold LUT leakage was not rejected")

    invalid_clip = clip.copy()
    invalid_clip[0] = 20
    try:
        validate_training_contract(plan, quality, invalid_clip, folds)
    except RuntimeError as error:
        if "0..19" not in str(error):
            raise
    else:
        raise RuntimeError("invalid VCG clip position was not rejected")

    print("training protocol tests passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
