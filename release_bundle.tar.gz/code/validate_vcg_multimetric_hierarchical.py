#!/usr/bin/env python3
"""Validate hierarchical VCG multi-metric evidence against source rows and index."""

from __future__ import annotations

import argparse
import json
import math
import tempfile
from pathlib import Path

from reanalyse_vcg_multimetric_hierarchical import (
    OUTPUT_SCHEMA,
    main as reanalyse_main,
    sha256_file,
)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--result", type=Path, required=True)
    parser.add_argument("--index", type=Path, required=True)
    parser.add_argument("--evidence", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    observed = json.loads(args.evidence.read_text(encoding="utf-8"))
    if observed.get("schema") != OUTPUT_SCHEMA or observed.get("status") != "completed":
        raise ValueError("unexpected or incomplete hierarchical evidence")

    with tempfile.TemporaryDirectory(prefix="vcg_multimetric_validate_") as temp_dir:
        recomputed_path = Path(temp_dir) / "recomputed.json"
        import sys

        previous_argv = sys.argv
        try:
            sys.argv = [
                "reanalyse_vcg_multimetric_hierarchical.py",
                "--result",
                str(args.result),
                "--index",
                str(args.index),
                "--output",
                str(recomputed_path),
            ]
            reanalyse_main()
        finally:
            sys.argv = previous_argv
        recomputed = json.loads(recomputed_path.read_text(encoding="utf-8"))

    if observed != recomputed:
        raise ValueError("hierarchical evidence differs from independent recomputation")
    for metric, values in observed["summary"].items():
        interval = values["hierarchical_difference_ci95"]
        if len(interval) != 2 or not all(math.isfinite(float(value)) for value in interval):
            raise ValueError(f"invalid interval for {metric}")
        if float(interval[0]) > float(interval[1]):
            raise ValueError(f"reversed interval for {metric}")

    validation = {
        "schema": "vcg-selector-multimetric-hierarchical-validation.v1",
        "status": "pass",
        "evidence_sha256": sha256_file(args.evidence),
        "source_result_sha256": sha256_file(args.result),
        "test_index_sha256": sha256_file(args.index),
        "metric_count": len(observed["summary"]),
        "bootstrap_replicates": observed["bootstrap"]["replicates"],
        "test_gt_as_model_input": observed["test_gt_as_model_input"],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(validation, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(validation, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
