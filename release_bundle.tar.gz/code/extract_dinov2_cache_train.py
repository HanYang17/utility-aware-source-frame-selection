#!/usr/bin/env python3
"""Extract normalized DINOv2 patch descriptors for the 2,900 training cases."""

from __future__ import annotations

import argparse
import json
import os
import time
import traceback
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from pillow_lut import load_cube_file
from transformers import AutoImageProcessor, Dinov2Model

from encoder_identity import verify_dinov2_root
from extract_aligned_rgb_cache_train import (
    atomic_json,
    atomic_npz,
    read_selected_frames,
    sha256_file,
)


def pool_16_to_8(tokens: torch.Tensor) -> torch.Tensor:
    batch, count, dimension = tokens.shape
    if count != 256:
        raise RuntimeError(f"DINOv2 patch count is not 16x16: {count}")
    grid = tokens.reshape(batch, 16, 16, dimension).permute(0, 3, 1, 2)
    return (
        F.avg_pool2d(grid, kernel_size=2, stride=2)
        .permute(0, 2, 3, 1)
        .reshape(batch, 64, dimension)
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--model-root", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--shard-id", type=int, required=True)
    parser.add_argument("--shard-count", type=int, required=True)
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    if not torch.cuda.is_available() or torch.cuda.device_count() != 1:
        raise RuntimeError("exactly one CUDA-visible GPU is required")
    if args.shard_count < 1 or not 0 <= args.shard_id < args.shard_count:
        raise ValueError("invalid shard")

    config = json.loads(args.config.read_text(encoding="utf-8"))
    plan = json.loads(args.plan.read_text(encoding="utf-8"))
    data = config["data"]
    total = int(data["train_case_count"])
    config_sha256 = sha256_file(args.config)
    if (
        config.get("status") != "final_method_configuration"
        or sha256_file(args.plan) != data["plan_sha256"]
        or plan.get("case_count") != total
        or plan.get("candidate_count_per_case") != 20
        or plan.get("final_test_gt_accessed") is not False
        or data.get("official_test_accessed") is not False
        or data.get("test_ground_truth_as_model_input") is not False
    ):
        raise RuntimeError("invalid training feature-extraction contract")
    cases_by_id = {int(row["case_id"]): row for row in plan["cases"]}
    if set(cases_by_id) != set(range(total)):
        raise RuntimeError("training plan must cover case IDs 0..2899 exactly")

    case_ids = [
        case_id for case_id in range(total)
        if case_id % args.shard_count == args.shard_id
    ]
    encoder_files = verify_dinov2_root(args.model_root)
    identity = {
        "schema": "reference-selector-semantic-cache.v1",
        "status": "running",
        "case_ids": case_ids,
        "case_count": len(case_ids),
        "candidate_count_per_case": 20,
        "patch_count": 64,
        "embedding_dimension": 384,
        "shard_id": args.shard_id,
        "shard_count": args.shard_count,
        "plan_sha256": sha256_file(args.plan),
        "config_sha256": config_sha256,
        "encoder_files": encoder_files,
        "official_test_accessed": False,
        "official_test_gt_accessed": False,
        "candidate_psnr_accessed": False,
    }
    manifest_path = args.output_root / "manifest.json"
    if manifest_path.exists() and not args.resume:
        raise RuntimeError(f"refusing to overwrite semantic cache: {manifest_path}")
    if manifest_path.exists():
        existing = json.loads(manifest_path.read_text(encoding="utf-8"))
        for key, value in identity.items():
            if key != "status" and existing.get(key) != value:
                raise RuntimeError(f"incompatible resumable semantic cache: {key}")

    completed_ids = set()
    for case_id in case_ids:
        case_path = args.output_root / "cases" / f"case_{case_id:04d}.npz"
        if not case_path.exists():
            continue
        with np.load(case_path, allow_pickle=False) as payload:
            semantic = payload["semantic"]
        if semantic.shape != (21, 64, 384) or semantic.dtype != np.float16:
            raise RuntimeError(f"invalid resumable semantic case: {case_path}")
        completed_ids.add(case_id)
    atomic_json(
        manifest_path,
        {**identity, "completed_case_count": len(completed_ids), "resumed": bool(args.resume)},
    )

    os.environ["HF_HUB_OFFLINE"] = "1"
    os.environ["TRANSFORMERS_OFFLINE"] = "1"
    processor = AutoImageProcessor.from_pretrained(
        str(args.model_root), local_files_only=True
    )
    model = Dinov2Model.from_pretrained(
        str(args.model_root), local_files_only=True
    ).requires_grad_(False).cuda().eval()
    started = time.time()
    try:
        for case_id in case_ids:
            if case_id in completed_ids:
                continue
            case = cases_by_id[case_id]
            candidate_indices = [int(value) for value in case["candidate_indices"]]
            reference_index = int(case["reference_index"])
            if len(candidate_indices) != 20:
                raise RuntimeError(f"case {case_id} does not contain 20 candidates")
            frames = read_selected_frames(
                Path(case["video_path"]), candidate_indices + [reference_index]
            )
            candidates = [frames[index] for index in candidate_indices]
            target_lut = load_cube_file(str(case["target_lut_path"]))
            reference = np.asarray(
                Image.fromarray(frames[reference_index]).filter(target_lut)
            )
            pixel_values = processor(
                images=candidates + [reference], return_tensors="pt"
            ).pixel_values.cuda()
            with torch.no_grad(), torch.cuda.amp.autocast(enabled=True):
                output = model(pixel_values=pixel_values, return_dict=True)
            semantic = F.normalize(output.last_hidden_state[:, 1:].float(), dim=-1)
            semantic = pool_16_to_8(semantic).cpu().numpy().astype(np.float16)
            atomic_npz(
                args.output_root / "cases" / f"case_{case_id:04d}.npz",
                semantic=semantic,
            )
            completed_ids.add(case_id)
            atomic_json(
                manifest_path,
                {
                    **identity,
                    "completed_case_count": len(completed_ids),
                    "last_completed_case_id": case_id,
                    "elapsed_seconds": time.time() - started,
                    "resumed": bool(args.resume),
                },
            )
        atomic_json(
            manifest_path,
            {
                **identity,
                "status": "completed",
                "completed_case_count": len(case_ids),
                "elapsed_seconds": time.time() - started,
                "resumed": bool(args.resume),
            },
        )
    except Exception as error:
        atomic_json(
            manifest_path,
            {
                **identity,
                "status": "failed",
                "completed_case_count": len(completed_ids),
                "error": repr(error),
                "traceback": traceback.format_exc(),
                "resumed": bool(args.resume),
            },
        )
        raise
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
