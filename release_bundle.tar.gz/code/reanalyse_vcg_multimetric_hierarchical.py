#!/usr/bin/env python3
"""Reanalyse paired VCG metrics with a LUT-then-case hierarchical bootstrap."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from collections import Counter
from pathlib import Path

import numpy as np


EXPECTED_INDEX_SHA256 = "1c5c955d53aa3eaa17f196acbbe2eb118ca377df364f3fecb313bd6eee1c9c41"
EXPECTED_RESULT_SCHEMA = "vcg-selector-multimetric-evaluation.v1"
OUTPUT_SCHEMA = "vcg-selector-multimetric-hierarchical-reanalysis.v1"
BOOTSTRAP_NAMESPACE = "vcg_multimetric_lut_case_hierarchical_bootstrap_v1"
BOOTSTRAP_SEED = 20260829
BOOTSTRAP_REPLICATES = 100_000
LUT_IDS = tuple(range(91, 101))
METRICS = ("psnr_db", "ssim", "lpips_alex", "delta_e00")
TEMPORAL_GAPS = (1, 5, 35)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def finite(value: object) -> float:
    result = float(value)
    if not math.isfinite(result):
        raise ValueError("non-finite metric value")
    return result


def load_case_luts(index_path: Path) -> tuple[dict[int, int], dict[int, str]]:
    if sha256_file(index_path) != EXPECTED_INDEX_SHA256:
        raise ValueError("test-index SHA256 mismatch")
    payload = json.loads(index_path.read_text(encoding="utf-8"))
    cases = payload.get("cases")
    if not isinstance(cases, list) or len(cases) != 100:
        raise ValueError("test index must contain exactly 100 cases")

    case_lut: dict[int, int] = {}
    lut_hashes: dict[int, str] = {}
    for case in cases:
        case_id = int(case["global_index"])
        lut_id = int(Path(case["lut"]).stem)
        if case_id in case_lut or lut_id not in LUT_IDS:
            raise ValueError("invalid or duplicate case-to-LUT mapping")
        lut_hash = str(case["lut_sha256"])
        if lut_id in lut_hashes and lut_hashes[lut_id] != lut_hash:
            raise ValueError(f"inconsistent hash for LUT {lut_id}")
        case_lut[case_id] = lut_id
        lut_hashes[lut_id] = lut_hash

    counts = Counter(case_lut.values())
    if set(case_lut) != set(range(100)):
        raise ValueError("test case IDs must be exactly 0..99")
    if set(counts) != set(LUT_IDS) or any(counts[lut_id] != 10 for lut_id in LUT_IDS):
        raise ValueError("expected ten cases for each LUT ID 91..100")
    return case_lut, lut_hashes


def load_rows(result_path: Path) -> tuple[dict[str, list[dict]], dict]:
    payload = json.loads(result_path.read_text(encoding="utf-8"))
    if payload.get("schema") != EXPECTED_RESULT_SCHEMA or payload.get("status") != "completed":
        raise ValueError("unexpected or incomplete multi-metric result")
    if payload.get("index_sha256") != EXPECTED_INDEX_SHA256:
        raise ValueError("result/test-index identity mismatch")
    if int(payload.get("case_count", -1)) != 100:
        raise ValueError("multi-metric result must contain 100 cases")
    if payload.get("test_gt_as_model_input") is not False:
        raise ValueError("result does not exclude test ground truth from model inputs")

    rows: dict[str, list[dict]] = {}
    for arm in ("vcg", "proposed"):
        arm_rows = payload.get("arms", {}).get(arm, {}).get("rows", [])
        arm_rows = sorted(arm_rows, key=lambda row: int(row["case_id"]))
        if [int(row["case_id"]) for row in arm_rows] != list(range(100)):
            raise ValueError(f"{arm} case IDs must be exactly 0..99")
        for row in arm_rows:
            for metric in METRICS:
                finite(row[metric])
            temporal = row.get("temporal_warped_lpips", {})
            for gap in TEMPORAL_GAPS:
                finite(temporal[str(gap)])
        rows[arm] = arm_rows
    return rows, payload


def difference_matrix(
    rows: dict[str, list[dict]],
    case_lut: dict[int, int],
    metric: str,
    temporal_gap: int | None = None,
) -> np.ndarray:
    grouped: dict[int, list[float]] = {lut_id: [] for lut_id in LUT_IDS}
    for case_id in range(100):
        if temporal_gap is None:
            proposed = finite(rows["proposed"][case_id][metric])
            vcg = finite(rows["vcg"][case_id][metric])
        else:
            key = str(temporal_gap)
            proposed = finite(rows["proposed"][case_id]["temporal_warped_lpips"][key])
            vcg = finite(rows["vcg"][case_id]["temporal_warped_lpips"][key])
        grouped[case_lut[case_id]].append(proposed - vcg)
    matrix = np.asarray([grouped[lut_id] for lut_id in LUT_IDS], dtype=np.float64)
    if matrix.shape != (10, 10) or not np.isfinite(matrix).all():
        raise ValueError("invalid 10x10 LUT-case difference matrix")
    return matrix


def hierarchical_intervals(matrices: dict[str, np.ndarray]) -> dict[str, list[float]]:
    rng = np.random.Generator(np.random.PCG64(BOOTSTRAP_SEED))
    samples = {
        name: np.empty(BOOTSTRAP_REPLICATES, dtype=np.float64) for name in matrices
    }
    chunk_size = 1_000
    for start in range(0, BOOTSTRAP_REPLICATES, chunk_size):
        stop = min(start + chunk_size, BOOTSTRAP_REPLICATES)
        count = stop - start
        cluster_draws = rng.integers(0, 10, size=(count, 10), dtype=np.int8)
        case_draws = rng.integers(0, 10, size=(count, 10, 10), dtype=np.int8)
        for name, matrix in matrices.items():
            sampled = matrix[cluster_draws[..., None], case_draws]
            samples[name][start:stop] = sampled.mean(axis=(1, 2), dtype=np.float64)
    return {
        name: [float(x) for x in np.quantile(values, [0.025, 0.975], method="linear")]
        for name, values in samples.items()
    }


def arm_values(rows: list[dict], metric: str, temporal_gap: int | None = None) -> np.ndarray:
    if temporal_gap is None:
        return np.asarray([finite(row[metric]) for row in rows], dtype=np.float64)
    key = str(temporal_gap)
    return np.asarray(
        [finite(row["temporal_warped_lpips"][key]) for row in rows], dtype=np.float64
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--result", type=Path, required=True)
    parser.add_argument("--index", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    case_lut, lut_hashes = load_case_luts(args.index)
    rows, payload = load_rows(args.result)

    matrices: dict[str, np.ndarray] = {
        metric: difference_matrix(rows, case_lut, metric) for metric in METRICS
    }
    for gap in TEMPORAL_GAPS:
        name = f"temporal_warped_lpips_gap_{gap}"
        matrices[name] = difference_matrix(rows, case_lut, name, temporal_gap=gap)
    intervals = hierarchical_intervals(matrices)

    summary: dict[str, dict] = {}
    for metric in METRICS:
        vcg = arm_values(rows["vcg"], metric)
        proposed = arm_values(rows["proposed"], metric)
        summary[metric] = {
            "vcg_mean": float(vcg.mean()),
            "proposed_mean": float(proposed.mean()),
            "difference_proposed_minus_vcg": float((proposed - vcg).mean()),
            "hierarchical_difference_ci95": intervals[metric],
        }
    for gap in TEMPORAL_GAPS:
        name = f"temporal_warped_lpips_gap_{gap}"
        vcg = arm_values(rows["vcg"], name, temporal_gap=gap)
        proposed = arm_values(rows["proposed"], name, temporal_gap=gap)
        summary[name] = {
            "vcg_mean": float(vcg.mean()),
            "proposed_mean": float(proposed.mean()),
            "difference_proposed_minus_vcg": float((proposed - vcg).mean()),
            "hierarchical_difference_ci95": intervals[name],
        }

    output = {
        "schema": OUTPUT_SCHEMA,
        "status": "completed",
        "source_result_sha256": sha256_file(args.result),
        "test_index_sha256": sha256_file(args.index),
        "source_result_schema": payload["schema"],
        "case_count": 100,
        "cluster_count": 10,
        "cases_per_cluster": 10,
        "test_gt_as_model_input": False,
        "bootstrap": {
            "namespace": BOOTSTRAP_NAMESPACE,
            "seed": BOOTSTRAP_SEED,
            "rng": "numpy.random.Generator(PCG64)",
            "replicates": BOOTSTRAP_REPLICATES,
            "confidence_level": 0.95,
            "quantile_method": "linear",
            "outer_unit": "LUT",
            "inner_unit": "paired case within sampled LUT occurrence",
            "cluster_ids": list(LUT_IDS),
            "weighting": "equal sampled LUT occurrence and equal resampled case",
        },
        "case_to_lut": {str(case_id): case_lut[case_id] for case_id in range(100)},
        "lut_sha256": {str(lut_id): lut_hashes[lut_id] for lut_id in LUT_IDS},
        "summary": summary,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
