#!/usr/bin/env python3
"""Extract DINO-aligned 32x32 RGB for the 2,900 VCG training cases.

Only train videos and their provided training reference images are used.  The
cache contains no candidate quality, ranking, or official-test information.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import time
import traceback
from pathlib import Path
from typing import Any, Dict, List

import cv2
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from pillow_lut import load_cube_file
from transformers import AutoImageProcessor

from encoder_identity import verify_dinov2_root


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def atomic_json(path: Path, payload: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    partial = path.with_suffix(path.suffix + ".partial")
    partial.write_text(
        json.dumps(payload, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )
    os.replace(partial, path)


def atomic_npz(path: Path, **arrays: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    partial = path.with_suffix(path.suffix + ".partial")
    with partial.open("wb") as handle:
        np.savez_compressed(handle, **arrays)
    os.replace(partial, path)


def read_selected_frames(path: Path, indices: List[int]) -> Dict[int, np.ndarray]:
    wanted = set(indices)
    capture = cv2.VideoCapture(str(path))
    if not capture.isOpened():
        raise RuntimeError(f"cannot open video: {path}")
    frames: Dict[int, np.ndarray] = {}
    try:
        frame_index = 0
        while frame_index <= max(wanted):
            ok, frame = capture.read()
            if not ok:
                raise RuntimeError(f"decode stopped at frame {frame_index}: {path}")
            if frame_index in wanted:
                frames[frame_index] = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            frame_index += 1
    finally:
        capture.release()
    if set(frames) != wanted:
        raise RuntimeError(f"missing frames: {sorted(wanted - set(frames))}")
    return frames


def aligned_pixels(
    processor: Any,
    images: List[np.ndarray],
    resolution: int,
) -> np.ndarray:
    inputs = processor(images=images, return_tensors="pt")
    pixel_values = inputs.pixel_values.float()
    mean = torch.tensor(processor.image_mean)[None, :, None, None]
    std = torch.tensor(processor.image_std)[None, :, None, None]
    rgb = (pixel_values * std + mean).clamp(0.0, 1.0)
    rgb = F.interpolate(rgb, size=(resolution, resolution), mode="area")
    result = (
        rgb.mul(255.0)
        .round()
        .clamp(0.0, 255.0)
        .to(torch.uint8)
        .permute(0, 2, 3, 1)
        .contiguous()
        .numpy()
    )
    if result.shape != (21, resolution, resolution, 3):
        raise RuntimeError(f"unexpected aligned RGB shape: {result.shape}")
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--model-root", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--shard-id", type=int, required=True)
    parser.add_argument("--shard-count", type=int, required=True)
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    if args.shard_count < 1 or not 0 <= args.shard_id < args.shard_count:
        raise ValueError("invalid shard")

    config = json.loads(args.config.read_text(encoding="utf-8"))
    plan = json.loads(args.plan.read_text(encoding="utf-8"))
    data = config["data"]
    total = int(data["train_case_count"])
    if (
        sha256_file(args.plan) != data["plan_sha256"]
        or plan.get("case_count") != total
        or plan.get("candidate_count_per_case") != 20
        or plan.get("final_test_gt_accessed") is not False
        or data.get("official_test_accessed") is not False
        or data.get("test_ground_truth_as_model_input") is not False
        or data.get("candidate_psnr_as_model_input") is not False
    ):
        raise RuntimeError("invalid or test-contaminated 2,900-case training plan")
    cases_by_id = {int(row["case_id"]): row for row in plan["cases"]}
    if set(cases_by_id) != set(range(total)):
        raise RuntimeError("training plan must cover case IDs 0..2899 exactly")
    case_ids = [
        case_id for case_id in range(total)
        if case_id % args.shard_count == args.shard_id
    ]
    resolution = int(data["color_input_resolution"])
    identity = {
        "schema": "reference-selector-rgb-cache.v1",
        "status": "running",
        "case_ids": case_ids,
        "case_count": len(case_ids),
        "candidate_count_per_case": 20,
        "resolution": resolution,
        "shard_id": args.shard_id,
        "shard_count": args.shard_count,
        "plan_sha256": sha256_file(args.plan),
        "config_sha256": sha256_file(args.config),
        "processor_model_root": str(args.model_root),
        "official_test_accessed": False,
        "official_test_gt_accessed": False,
        "candidate_psnr_accessed": False,
        "target_lut_used_only_to_materialize_provided_training_reference": True,
    }
    manifest_path = args.output_root / "manifest.json"
    if manifest_path.exists():
        if not args.resume:
            raise RuntimeError(f"refusing to overwrite existing cache: {manifest_path}")
        existing = json.loads(manifest_path.read_text(encoding="utf-8"))
        for key, value in identity.items():
            if key != "status" and existing.get(key) != value:
                raise RuntimeError(f"incompatible resumable cache identity: {key}")
    completed_ids = set()
    for case_id in case_ids:
        case_path = args.output_root / "cases" / f"case_{case_id:04d}.npz"
        if not case_path.exists():
            continue
        with np.load(case_path, allow_pickle=False) as payload:
            pixels = payload["pixels"]
        if pixels.shape != (21, resolution, resolution, 3) or pixels.dtype != np.uint8:
            raise RuntimeError(f"invalid resumable RGB cache case: {case_path}")
        completed_ids.add(case_id)
    atomic_json(
        manifest_path,
        {**identity, "completed_case_count": len(completed_ids), "resumed": bool(args.resume)},
    )

    os.environ["HF_HUB_OFFLINE"] = "1"
    os.environ["TRANSFORMERS_OFFLINE"] = "1"
    encoder_files = verify_dinov2_root(args.model_root)
    processor = AutoImageProcessor.from_pretrained(
        str(args.model_root), local_files_only=True
    )
    started = time.time()
    try:
        for case_id in case_ids:
            if case_id in completed_ids:
                continue
            case = cases_by_id[case_id]
            if "/videos/train/" not in str(case["video_path"]):
                raise RuntimeError(f"non-train video in case {case_id}")
            candidate_indices = [int(value) for value in case["candidate_indices"]]
            reference_index = int(case["reference_index"])
            if len(candidate_indices) != 20:
                raise RuntimeError(f"case {case_id} does not contain 20 candidates")
            frames = read_selected_frames(
                Path(case["video_path"]), candidate_indices + [reference_index]
            )
            candidates = [frames[index] for index in candidate_indices]
            target_lut = load_cube_file(str(case["target_lut_path"]))
            reference = np.asarray(
                Image.fromarray(frames[reference_index]).filter(target_lut)
            )
            pixels = aligned_pixels(
                processor, candidates + [reference], resolution
            )
            case_path = args.output_root / "cases" / f"case_{case_id:04d}.npz"
            atomic_npz(case_path, pixels=pixels)
            completed_ids.add(case_id)
            atomic_json(
                manifest_path,
                {
                    **identity,
                    "completed_case_count": len(completed_ids),
                    "last_completed_case_id": case_id,
                    "elapsed_seconds": time.time() - started,
                    "resumed": bool(args.resume),
                },
            )
        atomic_json(
            manifest_path,
            {
                **identity,
                "status": "completed",
                "completed_case_count": len(case_ids),
                "elapsed_seconds": time.time() - started,
                "encoder_files": encoder_files,
                "resumed": bool(args.resume),
            },
        )
    except Exception as error:
        atomic_json(
            manifest_path,
            {
                **identity,
                "status": "failed",
                "completed_case_count": len(completed_ids),
                "error": repr(error),
                "traceback": traceback.format_exc(),
                "resumed": bool(args.resume),
            },
        )
        raise
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
