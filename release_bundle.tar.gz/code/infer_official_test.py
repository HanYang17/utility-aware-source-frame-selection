#!/usr/bin/env python3
"""Run the final selector on 100 test cases without reading evaluation targets."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
from typing import Dict, List

import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset

from model import ReferenceFrameUtilityModel
from encoder_identity import expected_encoder_files


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def atomic_json(path: Path, payload: Dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    partial = path.with_suffix(path.suffix + ".partial")
    partial.write_text(
        json.dumps(payload, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )
    os.replace(partial, path)


def validate_manifests(
    semantic_root: Path,
    pixel_root: Path,
    clip_root: Path,
    expected_index_sha256: str,
) -> None:
    semantic = json.loads(
        (semantic_root / "shard_0" / "manifest.json").read_text(encoding="utf-8")
    )
    pixels = json.loads(
        (pixel_root / "shard_0" / "manifest.json").read_text(encoding="utf-8")
    )
    clip = json.loads(
        (clip_root / "shard_0" / "manifest.json").read_text(encoding="utf-8")
    )
    expected_dinov2 = expected_encoder_files("dinov2")
    expected_clip = expected_encoder_files("clip")
    if (
        semantic.get("schema") != "reference-selector-semantic-test-cache.v1"
        or semantic.get("status") != "completed"
        or int(semantic.get("completed_case_count", -1)) != 100
        or semantic.get("index_sha256") != expected_index_sha256
        or semantic.get("test_gt_accessed") is not False
        or semantic.get("encoder_files") != expected_dinov2
        or pixels.get("schema") != "reference-selector-rgb-test-cache.v1"
        or pixels.get("status") != "completed"
        or int(pixels.get("completed_case_count", -1)) != 100
        or pixels.get("index_sha256") != expected_index_sha256
        or pixels.get("test_gt_accessed") is not False
        or pixels.get("target_lut_accessed") is not False
        or pixels.get("candidate_psnr_accessed") is not False
        or pixels.get("encoder_files") != expected_dinov2
        or clip.get("schema") != "reference-selector-clip-test-cache.v1"
        or clip.get("status") != "completed"
        or int(clip.get("completed_case_count", -1)) != 100
        or clip.get("index_sha256") != expected_index_sha256
        or clip.get("test_gt_accessed") is not False
        or clip.get("candidate_psnr_accessed") is not False
        or clip.get("encoder_files") != expected_clip
    ):
        raise RuntimeError("invalid or evaluation-target-contaminated test cache")


class OfficialTestDataset(Dataset):
    def __init__(self, semantic_root: Path, pixel_root: Path, clip_root: Path) -> None:
        self.semantic_root = semantic_root
        self.pixel_root = pixel_root
        self.clip_root = clip_root

    def __len__(self) -> int:
        return 100

    def __getitem__(self, case_id: int) -> Dict[str, torch.Tensor]:
        with np.load(
            self.semantic_root / "shard_0" / "cases" / f"case_{case_id:04d}.npz",
            allow_pickle=False,
        ) as payload:
            semantic = payload["semantic"].astype(np.float32)
        with np.load(
            self.pixel_root / "shard_0" / "cases" / f"case_{case_id:04d}.npz",
            allow_pickle=False,
        ) as payload:
            pixels = payload["pixels"]
        with np.load(
            self.clip_root / "shard_0" / "cases" / f"case_{case_id:04d}.npz",
            allow_pickle=False,
        ) as payload:
            clip = payload["clip_embedding"].astype(np.float32)
        if semantic.shape != (21, 64, 384):
            raise RuntimeError(f"invalid semantic test case: {case_id}")
        if pixels.shape != (21, 32, 32, 3) or pixels.dtype != np.uint8:
            raise RuntimeError(f"invalid aligned RGB test case: {case_id}")
        if clip.shape != (21, 512) or not np.isfinite(clip).all():
            raise RuntimeError(f"invalid CLIP test case: {case_id}")
        return {
            "case_id": torch.tensor(case_id, dtype=torch.long),
            "candidate_semantic": torch.from_numpy(semantic[:20]),
            "candidate_pixels": torch.from_numpy(pixels[:20]),
            "reference_semantic": torch.from_numpy(semantic[20]),
            "reference_pixels": torch.from_numpy(pixels[20]),
            "candidate_clip": torch.from_numpy(clip[:20]),
            "reference_clip": torch.from_numpy(clip[20]),
        }


@torch.no_grad()
def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--semantic-cache-root", type=Path, required=True)
    parser.add_argument("--pixel-cache-root", type=Path, required=True)
    parser.add_argument("--clip-cache-root", type=Path, required=True)
    parser.add_argument("--expected-index-sha256", required=True)
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise RuntimeError(f"refusing to overwrite predictions: {args.output}")
    if not torch.cuda.is_available() or torch.cuda.device_count() != 1:
        raise RuntimeError("exactly one CUDA-visible GPU is required")
    validate_manifests(
        args.semantic_cache_root,
        args.pixel_cache_root,
        args.clip_cache_root,
        args.expected_index_sha256,
    )
    config = json.loads(args.config.read_text(encoding="utf-8"))
    if (
        config.get("status") != "final_method_configuration"
        or config["data"].get("test_ground_truth_as_model_input") is not False
        or config["data"].get("candidate_psnr_as_model_input") is not False
    ):
        raise RuntimeError("test configuration violates the inference contract")
    device = torch.device("cuda:0")
    model = ReferenceFrameUtilityModel(config).to(device)
    checkpoint = torch.load(args.checkpoint, map_location=device)
    if (
        checkpoint.get("config") != config
        or int(checkpoint.get("epoch", -1)) < 1
    ):
        raise RuntimeError("checkpoint is not tied to the supplied configuration")
    model.load_state_dict(checkpoint["model_state"])
    model.eval()
    loader = DataLoader(
        OfficialTestDataset(args.semantic_cache_root, args.pixel_cache_root, args.clip_cache_root),
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=0,
    )
    rows: List[Dict] = []
    for batch in loader:
        score = model(
            batch["candidate_semantic"].to(device),
            batch["candidate_pixels"].to(device),
            batch["reference_semantic"].to(device),
            batch["reference_pixels"].to(device),
            batch["candidate_clip"].to(device),
            batch["reference_clip"].to(device),
        ).cpu().numpy()
        selected = score.argmax(axis=1)
        for batch_index, case_id in enumerate(batch["case_id"].tolist()):
            rows.append({
                "case_id": int(case_id),
                "scores": score[batch_index].astype(float).tolist(),
                "selected_positions": [int(selected[batch_index])],
            })
    if [row["case_id"] for row in rows] != list(range(100)):
        raise RuntimeError("inference did not cover ordered case IDs 0..99")
    result = {
        "schema": "reference-selector-predictions.v1",
        "status": "completed",
        "case_count": 100,
        "strategy": "argmax",
        "k": 1,
        "checkpoint_sha256": sha256_file(args.checkpoint),
        "config_sha256": sha256_file(args.config),
        "index_sha256": args.expected_index_sha256,
        "official_test_accessed": True,
        "test_gt_accessed": False,
        "test_gt_as_model_input": False,
        "target_lut_accessed": False,
        "candidate_psnr_accessed": False,
        "rows": rows,
    }
    atomic_json(args.output, result)
    print(json.dumps({
        "status": "completed",
        "case_count": 100,
        "checkpoint_sha256": result["checkpoint_sha256"],
        "output_sha256": sha256_file(args.output),
    }, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
