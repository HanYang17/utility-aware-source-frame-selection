"""Downstream-utility-aware reference-frame selector."""
